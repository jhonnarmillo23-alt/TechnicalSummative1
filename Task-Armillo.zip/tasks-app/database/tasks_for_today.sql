-- Tasks for Today Management System: database export
-- Import with: mysql -u root -p < database/tasks_for_today.sql
-- Sample task dates are relative to CURDATE(), so "today" always has tasks
-- on the day you import this file.

CREATE DATABASE IF NOT EXISTS tasks_for_today
  CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE tasks_for_today;

DROP TABLE IF EXISTS tasks;
DROP TABLE IF EXISTS users;

CREATE TABLE tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  task_date DATE NOT NULL,
  created_at DATETIME NOT NULL
);

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  created_at DATETIME NOT NULL
);

INSERT INTO users (username, full_name, email, created_at) VALUES
('mdelacruz', 'Maria Dela Cruz', 'maria.delacruz@example.com', NOW());

INSERT INTO tasks (title, status, task_date, created_at) VALUES
-- Yesterday
('Submit weekly progress report to adviser',  'done',        DATE_SUB(CURDATE(), INTERVAL 1 DAY), NOW()),
('Back up the project database',              'done',        DATE_SUB(CURDATE(), INTERVAL 1 DAY), NOW()),
('Reply to client emails',                    'pending',     DATE_SUB(CURDATE(), INTERVAL 1 DAY), NOW()),
-- Today
('Review pull requests from teammates',       'in_progress', CURDATE(), NOW()),
('Fix login form validation messages',        'pending',     CURDATE(), NOW()),
('Prepare slides for Friday demo',            'pending',     CURDATE(), NOW()),
('Update README setup instructions',          'done',        CURDATE(), NOW()),
-- Tomorrow
('Run security checks on the API endpoints',  'pending',     DATE_ADD(CURDATE(), INTERVAL 1 DAY), NOW()),
('Meet with the capstone group',              'pending',     DATE_ADD(CURDATE(), INTERVAL 1 DAY), NOW()),
('Deploy latest build to the staging server', 'pending',     DATE_ADD(CURDATE(), INTERVAL 1 DAY), NOW()),
-- In two days
('Write unit tests for TaskModel',            'pending',     DATE_ADD(CURDATE(), INTERVAL 2 DAY), NOW()),
('Clean up unused CSS and images',            'pending',     DATE_ADD(CURDATE(), INTERVAL 2 DAY), NOW());
