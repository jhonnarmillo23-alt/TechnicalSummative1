# Tasks for Today Management System

IT0049 (Web System Technologies), Technical Summative Assessment 1.
Built with CodeIgniter 4, PHP, and MySQL.

| Route | Page | What it shows |
| --- | --- | --- |
| `/` | Welcome | Only tasks where `task_date` is today |
| `/tasks` | Task List | Every task, ordered by date |
| `/profile` | Profile | The single demo user |
| `/about` | About | Static page about the developer |

## Requirements

- PHP 8.1 or newer with the `intl`, `mbstring`, and `mysqlnd` extensions
- MySQL or MariaDB
- Composer

## Setup

This repository holds the application files. Put them on top of a fresh CodeIgniter 4 app:

```bash
composer create-project codeigniter4/appstarter tasks-for-today
cd tasks-for-today
```

1. Copy the contents of this repository into that folder, overwriting `app/Config/Routes.php`.
2. Copy the `env` file to `.env` and apply the values from `.env.example`
   (database credentials and `app.appTimezone = 'Asia/Manila'`).
3. Create the database:

   ```sql
   CREATE DATABASE tasks_for_today;
   ```

4. Create the tables and add sample data:

   ```bash
   php spark migrate
   php spark db:seed DatabaseSeeder
   ```

   Alternative: import `database/tasks_for_today.sql` with MySQL or phpMyAdmin instead of running the migration and seeder.

5. Start the server:

   ```bash
   php spark serve
   ```

   Open http://localhost:8080.

## Sample data

The seeder adds 12 tasks over 4 dates (yesterday, today, tomorrow, and two days ahead) and exactly 1 demo user. Dates are relative to the day you run the seeder. Run `php spark db:seed TaskSeeder` again if the Welcome page ever shows no tasks for the current day.

## Project structure

```
app/
  Config/Routes.php
  Controllers/   Home, Tasks, Profile, About
  Models/        TaskModel, UserModel
  Views/         layout, welcome, tasks/index, profile, about
  Database/
    Migrations/  tasks and users tables
    Seeds/       TaskSeeder, UserSeeder, DatabaseSeeder
public/css/style.css
database/tasks_for_today.sql
```

## Key queries

- Welcome page: `$this->where('task_date', date('Y-m-d'))->findAll()` in `TaskModel::getToday()`
- Task list: `$this->orderBy('task_date', 'ASC')->findAll()` in `TaskModel::getAllOrderedByDate()`

## Deployment

Point the web server's document root at the `public/` folder, upload the project, set `.env` with the host's database credentials, set `CI_ENVIRONMENT = production`, then run `php spark migrate` and `php spark db:seed DatabaseSeeder` (or import the SQL file).

## Developer

Jhonn, BSIT-WMA, FEU Institute of Technology.
