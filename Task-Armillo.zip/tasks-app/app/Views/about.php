<?= $this->extend('layout') ?>

<?= $this->section('content') ?>
<section class="page-head">
    <h1>About this system</h1>
</section>

<div class="prose">
    <p>Tasks for Today is a small task tracker. The home page shows only what is due today, and the task list shows everything. Both pages read from the same table, and only the query is different.</p>

    <h2>Developer</h2>
    <p>Built by <strong>Jhonn</strong>, BSIT-WMA student at FEU Institute of Technology, Manila.</p>

    <h2>Made for</h2>
    <p>IT0049 Web System Technologies, Technical Summative Assessment 1.</p>
</div>
<?= $this->endSection() ?>
