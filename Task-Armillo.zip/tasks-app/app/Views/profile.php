<?= $this->extend('layout') ?>

<?= $this->section('content') ?>
<section class="page-head">
    <h1>Profile</h1>
</section>

<?php if ($user): ?>
    <div class="profile">
        <div class="avatar" aria-hidden="true"><?= esc(strtoupper(substr($user['full_name'], 0, 1))) ?></div>
        <dl class="details">
            <div><dt>Full name</dt><dd><?= esc($user['full_name']) ?></dd></div>
            <div><dt>Username</dt><dd><?= esc($user['username']) ?></dd></div>
            <div><dt>Email</dt><dd><?= esc($user['email']) ?></dd></div>
            <div><dt>Member since</dt><dd><?= esc(date('F j, Y', strtotime($user['created_at']))) ?></dd></div>
        </dl>
    </div>
<?php else: ?>
    <div class="empty"><p>No user found. Run <code>php spark db:seed DatabaseSeeder</code> to add the demo user.</p></div>
<?php endif; ?>
<?= $this->endSection() ?>
