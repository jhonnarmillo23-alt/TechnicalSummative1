<?= $this->extend('layout') ?>

<?= $this->section('content') ?>
<?php $labels = ['pending' => 'Pending', 'in_progress' => 'In progress', 'done' => 'Done']; ?>
<section class="page-head">
    <h1>All tasks</h1>
    <p class="lede"><?= count($tasks) ?> <?= count($tasks) === 1 ? 'task' : 'tasks' ?>, ordered by date.</p>
</section>

<?php if (! empty($tasks)): ?>
    <div class="table-scroll">
        <table class="tasks-table">
            <thead>
                <tr>
                    <th scope="col">Date</th>
                    <th scope="col">Task</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tasks as $task): ?>
                    <?php $isToday = $task['task_date'] === $today; ?>
                    <tr<?= $isToday ? ' class="is-today"' : '' ?>>
                        <td class="col-date">
                            <?= esc(date('D, M j, Y', strtotime($task['task_date']))) ?>
                            <?php if ($isToday): ?><span class="today-tag">Today</span><?php endif; ?>
                        </td>
                        <td><?= esc($task['title']) ?></td>
                        <td>
                            <span class="badge badge-<?= esc($task['status'], 'attr') ?>">
                                <?= esc($labels[$task['status']] ?? ucfirst($task['status'])) ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <div class="empty"><p>There are no tasks yet. Run <code>php spark db:seed DatabaseSeeder</code> to add sample data.</p></div>
<?php endif; ?>
<?= $this->endSection() ?>
