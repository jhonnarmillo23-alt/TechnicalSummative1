<?= $this->extend('layout') ?>

<?= $this->section('content') ?>
<?php
$labels = ['pending' => 'Pending', 'in_progress' => 'In progress', 'done' => 'Done'];
$total  = count($tasks);
$left   = count(array_filter($tasks, fn ($t) => $t['status'] !== 'done'));
?>
<section class="day-head">
    <div class="day-number" aria-hidden="true"><?= date('j') ?></div>
    <div>
        <h1><?= esc($todayLong) ?></h1>
        <?php if ($total > 0): ?>
            <p class="lede"><?= $left ?> of <?= $total ?> <?= $total === 1 ? 'task' : 'tasks' ?> still to do today.</p>
        <?php else: ?>
            <p class="lede">No tasks are scheduled for today.</p>
        <?php endif; ?>
    </div>
</section>

<?php if ($total > 0): ?>
    <ul class="checklist">
        <?php foreach ($tasks as $task): ?>
            <li class="check-row status-<?= esc($task['status'], 'attr') ?>">
                <span class="box" aria-hidden="true"></span>
                <span class="check-title"><?= esc($task['title']) ?></span>
                <span class="badge badge-<?= esc($task['status'], 'attr') ?>">
                    <?= esc($labels[$task['status']] ?? ucfirst($task['status'])) ?>
                </span>
            </li>
        <?php endforeach; ?>
    </ul>
    <p class="note"><a href="<?= site_url('tasks') ?>">See every task, including other days</a></p>
<?php else: ?>
    <div class="empty">
        <p>Tasks with today's date will appear here. Add some to the <code>tasks</code> table or run the seeder again.</p>
        <p><a href="<?= site_url('tasks') ?>">Browse all tasks</a></p>
    </div>
<?php endif; ?>
<?= $this->endSection() ?>
