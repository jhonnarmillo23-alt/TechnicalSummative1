<?php $path = trim(uri_string(), '/'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= esc($pageTitle ?? 'Tasks for Today') ?> | Tasks for Today</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700&family=Public+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
    <header class="site-header">
        <div class="wrap header-inner">
            <a class="brand" href="<?= site_url('/') ?>">Tasks for Today</a>
            <nav class="nav" aria-label="Main">
                <a href="<?= site_url('/') ?>"<?= $path === '' ? ' aria-current="page"' : '' ?>>Today</a>
                <a href="<?= site_url('tasks') ?>"<?= $path === 'tasks' ? ' aria-current="page"' : '' ?>>All tasks</a>
                <a href="<?= site_url('profile') ?>"<?= $path === 'profile' ? ' aria-current="page"' : '' ?>>Profile</a>
                <a href="<?= site_url('about') ?>"<?= $path === 'about' ? ' aria-current="page"' : '' ?>>About</a>
            </nav>
        </div>
    </header>

    <main class="wrap">
        <?= $this->renderSection('content') ?>
    </main>

    <footer class="site-footer">
        <div class="wrap">Tasks for Today Management System &middot; IT0049 TSA1</div>
    </footer>
</body>
</html>
