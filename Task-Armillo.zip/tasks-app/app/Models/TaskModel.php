<?php

namespace App\Models;

use CodeIgniter\Model;

class TaskModel extends Model
{
    protected $table         = 'tasks';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['title', 'status', 'task_date'];

    // The schema only has created_at, so updated_at is disabled.
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = '';

    /**
     * Tasks scheduled for today only.
     */
    public function getToday(): array
    {
        return $this->where('task_date', date('Y-m-d'))
                    ->orderBy('id', 'ASC')
                    ->findAll();
    }

    /**
     * Every task, ordered by date (then by id for a stable order within a day).
     */
    public function getAllOrderedByDate(): array
    {
        return $this->orderBy('task_date', 'ASC')
                    ->orderBy('id', 'ASC')
                    ->findAll();
    }
}
