<?php

namespace App\Controllers;

use App\Models\TaskModel;

class Tasks extends BaseController
{
    public function index()
    {
        $model = new TaskModel();

        return view('tasks/index', [
            'pageTitle' => 'All tasks',
            'tasks'     => $model->getAllOrderedByDate(),
            'today'     => date('Y-m-d'),
        ]);
    }
}
