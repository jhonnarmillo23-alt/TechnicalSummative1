<?php

namespace App\Controllers;

use App\Models\TaskModel;

class Home extends BaseController
{
    public function index()
    {
        $model = new TaskModel();

        return view('welcome', [
            'pageTitle' => 'Today',
            'tasks'     => $model->getToday(),
            'todayLong' => date('l, F j, Y'),
        ]);
    }
}
