<?php

namespace App\Controllers;

use App\Models\UserModel;

class Profile extends BaseController
{
    public function index()
    {
        $model = new UserModel();

        return view('profile', [
            'pageTitle' => 'Profile',
            'user'      => $model->getDemoUser(),
        ]);
    }
}
