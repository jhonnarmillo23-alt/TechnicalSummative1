<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class TaskSeeder extends Seeder
{
    public function run()
    {
        // Dates are relative to the day the seeder runs, so "today" always has tasks.
        $today     = date('Y-m-d');
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $tomorrow  = date('Y-m-d', strtotime('+1 day'));
        $twoDays   = date('Y-m-d', strtotime('+2 days'));
        $now       = date('Y-m-d H:i:s');

        $rows = [
            // Yesterday
            ['Submit weekly progress report to adviser',  'done',        $yesterday],
            ['Back up the project database',              'done',        $yesterday],
            ['Reply to client emails',                    'pending',     $yesterday],

            // Today
            ['Review pull requests from teammates',       'in_progress', $today],
            ['Fix login form validation messages',        'pending',     $today],
            ['Prepare slides for Friday demo',            'pending',     $today],
            ['Update README setup instructions',          'done',        $today],

            // Tomorrow
            ['Run security checks on the API endpoints',  'pending',     $tomorrow],
            ['Meet with the capstone group',              'pending',     $tomorrow],
            ['Deploy latest build to the staging server', 'pending',     $tomorrow],

            // In two days
            ['Write unit tests for TaskModel',            'pending',     $twoDays],
            ['Clean up unused CSS and images',            'pending',     $twoDays],
        ];

        $data = [];
        foreach ($rows as [$title, $status, $date]) {
            $data[] = [
                'title'      => $title,
                'status'     => $status,
                'task_date'  => $date,
                'created_at' => $now,
            ];
        }

        $this->db->table('tasks')->truncate();
        $this->db->table('tasks')->insertBatch($data);
    }
}
