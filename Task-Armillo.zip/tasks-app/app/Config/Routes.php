<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');          // Welcome: today's tasks only
$routes->get('tasks', 'Tasks::index');     // Task List: every task
$routes->get('profile', 'Profile::index'); // Profile: the demo user
$routes->get('about', 'About::index');     // About: static developer page
